# 간단 버전 placeholder
print('은유 기계 준비 완료!')
